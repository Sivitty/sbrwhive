#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --multi-algorithm-job-mode 3 --algorithm randomepic\;xdag --pool epic.hashrate.to:4000!51pool.online:4416!eu.epicmine.org:3333\;equal.xdag.org:13656!xdagmine.com:13654 --wallet epic-username-here\;xdag-wallet-here
