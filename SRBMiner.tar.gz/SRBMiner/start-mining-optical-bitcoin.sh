#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-cpu --algorithm heavyhash --pool stratum-eu.rplant.xyz:7064 --wallet obtc-wallet-here --password x
