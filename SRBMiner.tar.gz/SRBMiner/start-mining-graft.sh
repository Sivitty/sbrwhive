#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm randomgrft --pool graft.westcoastxmr.ca:3333 --wallet GBv4PutAtANSuy9SQaqt5ZYAN76QLnRGha2RTph9i3WF5KEoGGykCQNcz2DfvzwaFua5vAoCFWow5CGrhZc6b4wcA42iXZh
