#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-cpu --algorithm dynamo --pool pool1.dynamocoin.org:4567 --wallet dy1qgh328sma9yy58cmt5wmacvr42s6xkwdrz5va4k
